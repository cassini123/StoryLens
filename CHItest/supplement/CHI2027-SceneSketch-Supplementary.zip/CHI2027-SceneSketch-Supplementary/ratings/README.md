# Ratings

- `self_alignment.csv` — per-task 1–7 self-alignment and result-alignment (all sessions).
- `demographics.csv` — cinematography / visual / generative-AI experience.
- `expert_ratings.csv` — expert 0–3 rubric / P_norm. **This deployment did not collect expert ratings;** the file is header-only.

End-of-session Likert (perceived control / usefulness / effort / confidence) was shown in the client but was not written into the official export tables.
