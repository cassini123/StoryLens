# Operator notes (anonymized)

The study client is a Vite + React app in `source/` of this package.

- Participants open `/chitest/` (or `/` in local `npm run dev`) and enter a participant code.
- Do not tell participants which group they are in.
- Scaffold (export `group` = 1): T0×1 + T1×2 + T2×2 + T3×2
- Control (export `group` = 0): T0×1 + T1×4 + T3×2
- Researcher login is required only to open expert / coding / bulk export pages.
  Credentials are redacted in this supplement (`researcher-a` / `researcher-b`).
- Each finished session downloads a ZIP of official CSV/JSON tables.
- Sketch pixels are never sent to the image API (`api_input = image+text`, `sketch_sent = false`).
- Do not bump `chitest.store.v*` during an in-progress study; it wipes local client state.

See `experiment-protocol.md` for inclusion rules and logging.
