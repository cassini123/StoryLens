import { useEffect, useMemo, useRef, useState } from 'react'
import { getImage, stageHasSketch, stimulusUrl } from '../shared/config'
import { SurpriseModal, SurpriseTrigger } from '../shared/SurpriseModal'
import { getGeneratedImage, saveGeneratedImage } from '../shared/imageStore'
import { checkJimengHealth, generateImageFromIntent, JIMENG_OVERALL_TIMEOUT_MS, type JimengHealth } from '../shared/jimeng'
import {
  addGeneration,
  addSketchAction,
  addSketchSnapshot,
  addTextVersion,
  closeAutoPromptView,
  closeResultView,
  closeSketchEdit,
  closeTextEdit,
  currentTask,
  finalizeAutoPrompts,
  interpretSketch,
  userPromptPayload,
  logEvent,
  openResultView,
  recordCopyEvent,
  recordPasteEvent,
} from '../shared/logging'
import { composeConditioning } from '../shared/media'
import { lastSuccessfulGeneration, resolveConditioningImage } from '../shared/generationChain'
import { publicJimengError } from '../shared/retry'
import {
  canAttemptGeneration,
  canAttemptInterpret,
  canSatisfyTask,
  recoverStuckGeneration,
  t2NeedsGenerationAfterInterpret,
} from '../shared/protocol'
import { generateSketch } from '../shared/sketch/generate'
import { SceneEditor } from '../shared/sketch/SceneEditor'
import { sceneToSvg } from '../shared/sketch/render'
import { cloneScene } from '../shared/sketch/templates'
import { sceneToAutoPrompt } from '../shared/sketchToPrompt'
import { assignGroup, buildTaskPlan, groupCode, isShortSession, nextParticipantId, randomPattern } from '../shared/schedule'
import { createSessionBase, hydrateRuntimeForTask, stashTaskDraft, summarizeTask } from '../shared/sessionInit'
import { markExportReadiness } from '../shared/validation'
import { pastedFromAuto } from '../shared/textCompare'
import { downloadParticipantPacket } from '../shared/export'
import { abandonSession, getActiveSession, getSession, loadStore, sessionsForParticipant, upsertSession } from '../shared/store'
import { openRestartConfirm, restartLocalSession } from '../shared/restart'
import { nowIso } from '../shared/time'
import type {
  Demographics,
  ExperienceLevel,
  ImageDef,
  Session,
  SketchEdit,
  SketchScene,
  SubjectiveRatings,
  TaskRun,
  TextType,
} from '../shared/types'
import { MAX_ROUNDS } from '../shared/types'
import { SessionChrome } from '../shared/SessionChrome'
import { useI18n } from '../shared/i18n'
import { Button, Field, FooterBar, Likert } from '../shared/ui'

const emptyDemo: Demographics = {
  cinematography_experience: '',
  cinematography_years: '',
  visual_experience: '',
  ai_familiarity: '',
  design_background: null,
  film_background: null,
  film_years: '',
  ai_experience: '',
  image_gen_experience: '',
}

function persist(session: Session): Session {
  try {
    upsertSession(session)
  } catch {
    /* Safari private mode / quota: keep the in-memory session usable. */
  }
  return session
}

function maybeLogResume(session: Session): Session {
  try {
    const key = `chitest.resume.${session.session_id}`
    if (sessionStorage.getItem(key)) return session
    sessionStorage.setItem(key, '1')
  } catch {
    /* ignore */
  }
  const last = session.event_log[session.event_log.length - 1]
  if (!last) return session
  if (last.event_type === 'session_start' || last.event_type === 'group_assignment' || last.event_type === 'session_resume') {
    return session
  }
  logEvent(session, 'session_resume', { via: 'browser_reentry', session_id: session.session_id })
  session.session_status = 'resumed'
  return session
}

function confirmRestart(session: Session, message: string, cancelLabel: string, okLabel: string): void {
  openRestartConfirm({
    message,
    cancelLabel,
    okLabel,
    onConfirm: () => restartLocalSession(session),
  })
}

export function ParticipantApp() {
  const { t } = useI18n()
  const existing = useMemo(() => loadStore().sessions, [])
  const [session, setSession] = useState<Session | null>(() => getActiveSession() ?? null)
  const [setupId, setSetupId] = useState(nextParticipantId(existing))
  const [demo, setDemo] = useState<Demographics>(emptyDemo)
  const [health, setHealth] = useState<JimengHealth | null>(null)

  useEffect(() => {
    void checkJimengHealth().then(setHealth)
  }, [])

  if (!session) {
    const ready =
      setupId.trim().length > 0 &&
      demo.cinematography_experience !== '' &&
      demo.visual_experience !== '' &&
      demo.ai_familiarity !== ''
    return (
      <SessionChrome title={t.setupTitle} extra={t.studyBrand} session={null}>
        <main className="page">
          <p className="lead">{t.setupLead}</p>
          {health && !health.credentials ? <p className="api-status bad">{t.apiMissing}</p> : null}
          <div className="stack">
            <Field label={t.participantId}>
              <input value={setupId} onChange={(e) => setSetupId(e.target.value.trim())} />
            </Field>
            <Field label={t.cineExp}>
              <select
                value={demo.cinematography_experience}
                onChange={(e) =>
                  setDemo({
                    ...demo,
                    cinematography_experience: e.target.value as ExperienceLevel | '',
                    film_background: e.target.value !== 'none',
                  })
                }
              >
                <option value="">{t.select}</option>
                <option value="none">{t.none}</option>
                <option value="some">{t.some}</option>
                <option value="frequent">{t.frequent}</option>
              </select>
            </Field>
            <Field label={t.cineYears}>
              <input
                value={demo.cinematography_years}
                onChange={(e) => setDemo({ ...demo, cinematography_years: e.target.value, film_years: e.target.value })}
                placeholder="0"
              />
            </Field>
            <Field label={t.visualExp}>
              <select
                value={demo.visual_experience}
                onChange={(e) =>
                  setDemo({
                    ...demo,
                    visual_experience: e.target.value as ExperienceLevel | '',
                    design_background: e.target.value !== 'none',
                  })
                }
              >
                <option value="">{t.select}</option>
                <option value="none">{t.none}</option>
                <option value="some">{t.some}</option>
                <option value="frequent">{t.frequent}</option>
              </select>
            </Field>
            <Field label={t.aiFam}>
              <select
                value={demo.ai_familiarity}
                onChange={(e) =>
                  setDemo({
                    ...demo,
                    ai_familiarity: e.target.value as ExperienceLevel | '',
                    ai_experience: e.target.value as ExperienceLevel | '',
                    image_gen_experience: e.target.value as ExperienceLevel | '',
                  })
                }
              >
                <option value="">{t.select}</option>
                <option value="none">{t.none}</option>
                <option value="some">{t.some}</option>
                <option value="frequent">{t.frequent}</option>
              </select>
            </Field>
          </div>
        </main>
        <FooterBar>
          <Button
            fill
            disabled={!ready}
            onClick={() => {
              const id = setupId.trim()
              if (getSession(id)?.completed_at) {
                alert(t.idUsed)
                return
              }
              const prior = getSession(id)
              if (prior && !prior.completed_at && prior.session_status !== 'abandoned') {
                if (confirm(t.resumeOrReroll)) {
                  logEvent(prior, 'session_resume', { session_id: prior.session_id, via: 'same_id' })
                  prior.session_status = 'resumed'
                  setSession(persist(prior))
                  return
                }
                abandonSession(id)
              }
              const priorCount = sessionsForParticipant(id).length
              const base = `S${id.replace(/^P/i, '')}`
              const sessionId = priorCount === 0 ? base : `${base}_${priorCount + 1}`
              const group = assignGroup()
              const pattern = randomPattern()
              const plan = buildTaskPlan(id, group, pattern)
              const created = createSessionBase({
                participantId: id,
                sessionId,
                group,
                pattern,
                plan,
                demographics: demo,
                shortSession: isShortSession(),
                startedAt: nowIso(),
              })
              logEvent(created, 'session_start')
              logEvent(created, 'participant_setup_complete')
              logEvent(created, 'group_assignment', {
                group: groupCode(created.experimental_group),
                experimental_group: created.experimental_group,
                assignment_pattern: created.assignment_pattern,
                condition_order: created.condition_order,
                task_sequence_version: created.task_sequence_version,
                short_session: created.short_session,
              })
              setSession(persist(created))
            }}
          >
            {t.continue}
          </Button>
        </FooterBar>
      </SessionChrome>
    )
  }

  return <ParticipantFlow session={session} setSession={setSession} />
}

function ParticipantFlow({
  session,
  setSession,
}: {
  session: Session
  setSession: (session: Session | null) => void
}) {
  const { t, locale } = useI18n()
  const changeTimer = useRef<number | null>(null)
  const sessionRef = useRef(session)
  sessionRef.current = session
  const genTokenRef = useRef(0)
  const genAbortRef = useRef<AbortController | null>(null)
  const generateStartedAt = useRef(0)
  const watchdogRef = useRef<number | null>(null)
  const [surpriseOpen, setSurpriseOpen] = useState(false)

  function clearGenerateWatch() {
    if (watchdogRef.current != null) {
      window.clearInterval(watchdogRef.current)
      watchdogRef.current = null
    }
  }

  function bumpGenerateToken() {
    genTokenRef.current += 1
    genAbortRef.current?.abort()
    genAbortRef.current = null
    clearGenerateWatch()
  }

  function abandonInFlightGenerate(reason: 'cancel' | 'timeout') {
    bumpGenerateToken()
    const next = structuredClone(sessionRef.current)
    if (!recoverStuckGeneration(next)) return
    logEvent(next, 'generation_recovery', { via: reason, duplicate_generation_prevented: true })
    next.runtime.generate_error = reason === 'cancel' ? t.generateCancelled : t.generateStuck
    setSession(persist(next))
  }

  function update(mutator: (next: Session) => void) {
    const next = structuredClone(session)
    mutator(next)
    setSession(persist(next))
  }

  useEffect(() => {
    const current = structuredClone(sessionRef.current)
    try {
      const loadKey = `chitest.pageload.${current.session_id}`
      const origin = String(performance.timeOrigin)
      const previousOrigin = sessionStorage.getItem(loadKey)
      if (previousOrigin && previousOrigin !== origin) {
        logEvent(current, 'browser_reload', { session_id: current.session_id })
        persist(current)
        setSession(current)
      } else if (!previousOrigin) {
        sessionStorage.setItem(loadKey, origin)
        maybeLogResume(current)
        persist(current)
        setSession(current)
      }
      sessionStorage.setItem(loadKey, origin)
    } catch {
      /* ignore */
    }
    const next = structuredClone(sessionRef.current)
    const active = currentTask(next)
    let recovered = false
    if (recoverStuckGeneration(next)) {
      logEvent(next, 'generation_recovery', { via: 'reload', duplicate_generation_prevented: true })
      recovered = true
    }
    if (active) {
      const shown = next.generations.find((item) => item.generation_id === next.runtime.last_output_image_id)
      if (shown && !shown.success) {
        const lastOk = lastSuccessfulGeneration(next, active.task_id)
        next.runtime.last_output_image_id = lastOk?.generation_id || lastOk?.output_image_id || ''
        next.runtime.step = next.runtime.last_output_image_id ? 'review' : 'describe'
        recovered = true
      }
    }
    if (recovered) {
      persist(next)
      setSession(next)
    }
  }, [session.session_id])

  useEffect(() => {
    const onExit = () => {
      const next = structuredClone(sessionRef.current)
      logEvent(next, 'page_exit', { visibility: document.visibilityState })
      persist(next)
    }
    window.addEventListener('beforeunload', onExit)
    const onVisibility = () => {
      const next = structuredClone(sessionRef.current)
      if (document.visibilityState === 'hidden') {
        logEvent(next, 'visibility_hidden')
        persist(next)
        return
      }
      logEvent(next, 'visibility_visible')
      if (
        next.runtime.step === 'generating' &&
        generateStartedAt.current > 0 &&
        Date.now() - generateStartedAt.current >= JIMENG_OVERALL_TIMEOUT_MS
      ) {
        recoverStuckGeneration(next)
        logEvent(next, 'generation_recovery', { via: 'timeout', duplicate_generation_prevented: true })
        next.runtime.generate_error = t.generateStuck
        bumpGenerateToken()
      }
      persist(next)
      setSession(next)
    }
    document.addEventListener('visibilitychange', onVisibility)
    return () => {
      window.removeEventListener('beforeunload', onExit)
      document.removeEventListener('visibilitychange', onVisibility)
    }
  }, [session.session_id])

  const task = currentTask(session)
  const planLength = session.tasks.length

  if (session.runtime.step === 'intro') {
    return (
      <SessionChrome
        session={session}
        title={t.introTitle}
        extra={session.participant_id}
        onSessionChange={setSession}
        onOpenTask={jumpToTask}
      >
        <main className="page">
          <p className="lead">{t.introduction}</p>
          <p>{t.introCount}</p>
        </main>
        <FooterBar style={{ justifyContent: 'space-between' }}>
          <Button onClick={() => confirmRestart(session, t.restartConfirm, t.cancel, t.confirmRestart)}>{t.startOver}</Button>
          <Button fill onClick={() => startTask(0)}>
            {t.continue}
          </Button>
        </FooterBar>
      </SessionChrome>
    )
  }

  if (session.runtime.step === 'questionnaire') {
    return (
      <Questionnaire
        session={session}
        onSessionChange={setSession}
        onOpenTask={jumpToTask}
        onChange={(subjective) => update((next) => { next.subjective = subjective })}
        onRestart={() => confirmRestart(session, t.restartConfirm, t.cancel, t.confirmRestart)}
        onSubmit={() =>
          update((next) => {
            next.completed_at = nowIso()
            next.runtime.step = 'complete'
            logEvent(next, 'session_end')
            markExportReadiness(next)
          })
        }
      />
    )
  }

  if (session.runtime.step === 'self_report') {
    return (
      <SelfReport
        session={session}
        onSessionChange={setSession}
        onOpenTask={jumpToTask}
        onRestart={() => confirmRestart(session, t.restartConfirm, t.cancel, t.confirmRestart)}
        onChange={(selfAlignment, resultAlignment) =>
          update((next) => {
            const active = currentTask(next)
            if (!active) return
            const stamp = nowIso()
            active.self_alignment_rating = selfAlignment
            active.self_alignment_timestamp = stamp
            active.result_alignment_rating = resultAlignment
            active.result_alignment_timestamp = stamp
          })
        }
        onSubmit={() =>
          update((next) => {
            const active = currentTask(next)
            if (active) {
              logEvent(next, 'self_alignment_submit', {
                self_alignment_rating: active.self_alignment_rating,
                result_alignment_rating: active.result_alignment_rating,
              })
            }
            endCurrentTask(next)
            goToNextTask(next)
          })
        }
      />
    )
  }

  if (session.runtime.step === 'complete') {
    return (
      <SessionChrome
        session={session}
        title={t.completeTitle}
        extra={session.participant_id}
        onSessionChange={setSession}
        onOpenTask={jumpToTask}
      >
        <main className="page">
          <p className="lead">{t.completeLead}</p>
          <div className="complete-actions">
            <Button fill onClick={() => void downloadParticipantPacket(session)}>
              {t.downloadData}
            </Button>
          </div>
        </main>
        <FooterBar style={{ justifyContent: 'space-between' }}>
          <Button onClick={() => confirmRestart(session, t.restartConfirm, t.cancel, t.confirmRestart)}>{t.startOver}</Button>
          <Button onClick={() => (window.location.hash = '#/')}>{t.home}</Button>
        </FooterBar>
        <SurpriseTrigger onClick={() => setSurpriseOpen(true)} />
        {surpriseOpen ? (
          <SurpriseModal participantId={session.participant_id} onClose={() => setSurpriseOpen(false)} />
        ) : null}
      </SessionChrome>
    )
  }

  if (!task) {
    return (
      <SessionChrome session={session} title={t.error} onSessionChange={setSession}>
        <main className="page">
          <p>{t.noTask}</p>
        </main>
      </SessionChrome>
    )
  }

  const image = getImage(task.image_id)
  const lastGen = [...session.generations].reverse().find((item) => item.task_id === task.task_id && item.success)
  const canSatisfy = canSatisfyTask(session, task, session.runtime.draft_text)
  const canGenerate = canAttemptGeneration(session, task)
  const canInterpret = canAttemptInterpret(session, task)

  function prepareTask(next: Session, index: number) {
    const active = next.tasks[index]
    if (!active) return
    if (active.started_at && next.event_log.some((item) => item.event_type === 'task_start' && item.task_id === active.task_id)) {
      hydrateRuntimeForTask(next, index)
      return
    }
    next.runtime.task_index = index
    next.runtime.round = 0
    next.runtime.draft_text = ''
    next.runtime.auto_prompt = ''
    next.runtime.auto_prompt_id = ''
    next.runtime.user_prompt_started = false
    next.runtime.auto_prompt_view_started = false
    next.runtime.auto_prompt_view_id = ''
    next.runtime.copied_from_auto = []
    next.runtime.working_scene = null
    next.runtime.baseline_scene = null
    next.runtime.generate_error = ''
    next.runtime.selected_node_id = null
    next.runtime.last_output_image_id = ''
    next.runtime.text_started = false
    next.runtime.sketch_editing = false
    next.runtime.result_viewing = false
    next.runtime.step = 'describe'
    if (active && !active.started_at) active.started_at = nowIso()
    if (active && stageHasSketch(active.stage)) {
      const record = generateSketch(active.image_id, '')
      next.runtime.working_scene = record.output.scene
      next.runtime.baseline_scene = cloneScene(record.output.scene)
      const snap = addSketchSnapshot(next, record.output.scene, record.output.svg, 'initial')
      logEvent(next, 'sketch_snapshot_created', { snapshot_id: snap.snapshot_id, kind: 'initial' })
    }
    logEvent(next, 'task_start')
    logEvent(next, `${active.stage}_task_start`)
    logEvent(next, 'image_view_start')
  }

  function jumpToTask(index: number) {
    if (sessionRef.current.runtime.step === 'generating') bumpGenerateToken()
    update((next) => {
      if (next.runtime.step === 'generating') {
        recoverStuckGeneration(next)
        logEvent(next, 'generation_recovery', { via: 'task_navigate', duplicate_generation_prevented: true })
      }
      if (index < 0 || index >= next.tasks.length) return
      if (index === next.runtime.task_index && next.runtime.step !== 'intro' && next.runtime.step !== 'questionnaire' && next.runtime.step !== 'complete' && next.runtime.step !== 'self_report') {
        return
      }
      const fromIndex = next.runtime.task_index
      const fromId = currentTask(next)?.task_id ?? null
      stashTaskDraft(next)
      closeTaskInstruments(next)
      prepareTask(next, index)
      const to = next.tasks[index]
      logEvent(next, 'task_navigate', {
        from_index: fromIndex,
        to_index: index,
        from_task_id: fromId,
        to_task_id: to?.task_id ?? null,
      })
    })
  }

  function startTask(index: number) {
    update((next) => {
      prepareTask(next, index)
    })
  }

  function saveDraftText(next: Session, type: TextType) {
    const text = next.runtime.draft_text.trim()
    const taskNow = currentTask(next)
    if (!taskNow || !text) return null
    const previous = [...next.text_versions].reverse().find((item) => item.task_id === taskNow.task_id)
    const version = addTextVersion(next, text, type, previous?.text_version_id || '')
    if (type === 'initial' && !taskNow.initial_text_version_id) {
      taskNow.initial_text_version_id = version.text_version_id
    }
    if (type !== 'auto' && type !== 'auto_interpretation') {
      taskNow.final_text_version_id = version.text_version_id
      taskNow.final_text = version.text
    }
    if (type === 'initial') taskNow.initial_text = version.text
    const eventType = type === 'initial' ? 'initial_text_submit' : 'text_submit'
    logEvent(next, eventType, {
      text_version_id: version.text_version_id,
      text_length: version.text_length,
      text_type: type,
      source: version.source,
    })
    if (type === 'user_revised' || (type === 'refined' && stageHasSketch(taskNow.stage))) {
      logEvent(next, 'user_prompt_submit', {
        text_version_id: version.text_version_id,
        text_length: version.text_length,
        ...userPromptPayload(next, previous?.text ?? ''),
      })
    }
    return version
  }

  function runInterpretSketch() {
    update((next) => {
      const active = currentTask(next)
      const scene = next.runtime.working_scene
      if (!active || !scene || !canAttemptInterpret(next, active)) return
      closeSketchEdit(next)
      const text =
        sceneToAutoPrompt(scene, locale, next.runtime.baseline_scene).trim() ||
        (locale === 'zh'
          ? '根据当前草图调整人物位置、距离和摄影机观察角度。'
          : 'Adjust the people’s positions, distances, and the camera angle from the current sketch.')
      interpretSketch(next, text)
    })
  }

  function closeTaskInstruments(next: Session) {
    closeSketchEdit(next)
    closeAutoPromptView(next)
    closeResultView(next)
    closeTextEdit(next)
  }

  function endCurrentTask(next: Session) {
    const active = currentTask(next)
    if (!active || active.ended_at) return
    closeTaskInstruments(next)
    if (next.runtime.draft_text.trim()) {
      const version = saveDraftText(next, 'final')
      if (version) finalizeAutoPrompts(next, version.text, version.text_version_id)
    }
    active.ended_at = nowIso()
    logEvent(next, 'image_view_end')
    logEvent(next, 'task_end')
    logEvent(next, `${active.stage}_task_end`)
    summarizeTask(next, active)
    logEvent(next, 'next_task_click')
  }

  function goToNextTask(next: Session) {
    const nextIndex = next.runtime.task_index + 1
    if (nextIndex >= next.tasks.length) {
      next.runtime.step = 'questionnaire'
      return
    }
    prepareTask(next, nextIndex)
  }

  function finishTask() {
    if (session.runtime.step === 'generating') return
    update((next) => {
      const active = currentTask(next)
      if (!active) return
      if (active.stage !== 'T0' && !canSatisfyTask(next, active, next.runtime.draft_text)) return
      if (active.stage === 'T0') {
        if (next.runtime.draft_text.trim()) saveDraftText(next, 'initial')
        endCurrentTask(next)
        goToNextTask(next)
        return
      }
      closeTaskInstruments(next)
      active.satisfied_round = next.runtime.round
      logEvent(next, 'satisfied_click', { round: next.runtime.round })
      next.runtime.step = 'self_report'
    })
  }

  async function runGenerate() {
    const text = session.runtime.draft_text.trim()
    if (!text) return
    if (genAbortRef.current || session.runtime.step === 'generating') return
    const live = structuredClone(session)
    const active = currentTask(live)
    if (!active || !active.ai_enabled || !canAttemptGeneration(live, active)) return
    const token = genTokenRef.current + 1
    genTokenRef.current = token
    const abort = new AbortController()
    genAbortRef.current = abort
    const nextRound = Math.min(MAX_ROUNDS, live.runtime.round + 1)
    closeResultView(live)
    closeSketchEdit(live)
    closeAutoPromptView(live)
    closeTextEdit(live)
    live.runtime.round = nextRound
    active.round = nextRound
    logEvent(live, 'generate_click')
    logEvent(live, 'round_start', { round: nextRound })
    const pendingAuto = t2NeedsGenerationAfterInterpret(live, active)
    const textType: TextType = nextRound === 1 ? 'initial' : pendingAuto ? 'user_revised' : 'refined'
    const version = saveDraftText(live, textType)
    if (version) finalizeAutoPrompts(live, version.text, version.text_version_id)
    const researchSnap =
      active.stage === 'T2' && live.runtime.working_scene && nextRound > 1
        ? addSketchSnapshot(
            live,
            live.runtime.working_scene,
            sceneToSvg(live.runtime.working_scene),
            'post_user_revision',
          )
        : null
    if (researchSnap) {
      logEvent(live, 'sketch_snapshot_created', { snapshot_id: researchSnap.snapshot_id, kind: researchSnap.kind })
    }
    live.runtime.step = 'generating'
    live.runtime.generate_error = ''
    const started = nowIso()
    generateStartedAt.current = Date.now()
    persist(live)
    setSession(live)
    clearGenerateWatch()
    watchdogRef.current = window.setInterval(() => {
      if (token !== genTokenRef.current) {
        clearGenerateWatch()
        return
      }
      if (Date.now() - generateStartedAt.current >= JIMENG_OVERALL_TIMEOUT_MS) {
        abandonInFlightGenerate('timeout')
      }
    }, 2000)

    const stillCurrent = () => token === genTokenRef.current && !abort.signal.aborted

    try {
      const chain = await resolveConditioningImage(live, active, nextRound)
      if (!stillCurrent()) return
      const apiPayload = {
        api_input: 'image+text' as const,
        sketch_sent: false,
        prompt: text,
        input_image_id: chain.input_image_id,
        previous_generation_id: chain.previous_generation_id,
        input_text: text,
        image_count: 1,
        model: 'jimeng_t2i_v40',
        model_version: 'jimeng_t2i_v40',
      }
      logEvent(live, 'generation_start', { ...apiPayload, sketch_included: false })
      persist(live)

      let images: string[] = []
      try {
        images = [await composeConditioning(chain.url, null)]
      } catch (error) {
        logEvent(live, 'error', { where: 'compose', message: String(error) })
        if (!stillCurrent()) return
        recoverStuckGeneration(live)
        live.runtime.generate_error = t.generateBusy
        persist(live)
        setSession(structuredClone(live))
        return
      }
      if (!stillCurrent()) return
      const result = await generateImageFromIntent(text, undefined, images, { signal: abort.signal })
      if (!stillCurrent()) return
      const ended = nowIso()
      const success = result.meta.status === 'done'
      const generation = addGeneration(live, {
        task_id: active.task_id,
        stage: active.stage,
        round: live.runtime.round,
        timestamp_start: started,
        timestamp_end: ended,
        latency_ms: Math.max(0, Date.parse(ended) - Date.parse(started)),
        model: result.meta.engine,
        model_version: 'jimeng_t2i_v40',
        input_image_id: chain.input_image_id,
        previous_generation_id: chain.previous_generation_id,
        generation_input_chain_valid: chain.generation_input_chain_valid,
        input_text: text,
        input_text_version_id: version?.text_version_id || active.final_text_version_id,
        input_sketch_snapshot_id: '',
        source_sketch_snapshot_id:
          researchSnap?.snapshot_id ||
          [...live.auto_prompts].reverse().find((item) => item.task_id === active.task_id)?.source_sketch_snapshot_id ||
          '',
        auto_prompt_id: pendingAuto ? live.runtime.auto_prompt_id : '',
        user_prompt_version_id: version?.text_version_id || '',
        sketch_sent: false,
        api_input: 'image+text',
        api_payload: { ...apiPayload, image_count: images.length, jimeng_task_id: result.meta.jimeng_task_id },
        output_image_id: '',
        success,
        error: result.meta.error,
        meta: result.meta,
      })
      if (success) {
        generation.output_image_id = generation.generation_id
        await saveGeneratedImage(generation.generation_id, result.data_url)
        if (!stillCurrent()) return
        live.runtime.last_output_image_id = generation.generation_id
        live.runtime.generate_error = ''
        live.runtime.step = 'review'
        live.runtime.user_prompt_started = false
        live.runtime.text_started = false
        active.rounds.push({
          round: live.runtime.round,
          text_version_id: active.final_text_version_id,
          generation_id: generation.generation_id,
          sketch_snapshot_before_id: researchSnap?.snapshot_id || '',
          sketch_snapshot_after_id: researchSnap?.snapshot_id || '',
          started_at: started,
          ended_at: ended,
        })
        openResultView(live)
      } else {
        live.runtime.round = Math.max(0, nextRound - 1)
        active.round = live.runtime.round
        live.runtime.generate_error =
          publicJimengError(result.meta.error || '') === 'busy' ? t.generateBusy : t.generateFailed
        live.runtime.step = live.runtime.last_output_image_id ? 'review' : 'describe'
      }
      logEvent(live, 'generation_end', {
        generation_id: generation.generation_id,
        success,
        latency_ms: generation.latency_ms,
        sketch_sent: false,
        api_input: 'image+text',
        input_image_id: chain.input_image_id,
        previous_generation_id: chain.previous_generation_id,
      })
      logEvent(live, success ? 'generation_success' : 'generation_failure', {
        error: result.meta.error,
        round: nextRound,
      })
      logEvent(live, 'round_end', { round: nextRound, success })
      persist(live)
      setSession(structuredClone(live))
    } catch (error) {
      if (!stillCurrent()) return
      logEvent(live, 'error', { where: 'generate', message: String(error) })
      recoverStuckGeneration(live)
      live.runtime.generate_error = t.generateBusy
      persist(live)
      setSession(structuredClone(live))
    } finally {
      if (token === genTokenRef.current) {
        genAbortRef.current = null
        clearGenerateWatch()
      }
    }
  }

  function onTextChange(value: string) {
    update((next) => {
      if (!next.runtime.text_started && value.trim()) {
        next.runtime.text_started = true
        logEvent(next, 'text_input_start')
      }
      const sketchStage = currentTask(next)?.auto_prompt_enabled && next.runtime.round >= 1
      if (sketchStage && !next.runtime.user_prompt_started && value !== next.runtime.auto_prompt) {
        next.runtime.user_prompt_started = true
        const previous = [...next.text_versions].reverse().find((item) => item.task_id === currentTask(next)?.task_id && item.text_type !== 'auto' && item.text_type !== 'auto_interpretation')
        logEvent(next, 'user_prompt_edit_start', userPromptPayload(next, previous?.text ?? next.runtime.draft_text))
        closeAutoPromptView(next)
      }
      next.runtime.draft_text = value
    })
    if (changeTimer.current) window.clearTimeout(changeTimer.current)
    changeTimer.current = window.setTimeout(() => {
      const latest = getSession(session.participant_id)
      if (!latest) return
      const sketchStage = currentTask(latest)?.auto_prompt_enabled && latest.runtime.round >= 1
      const previous = [...latest.text_versions]
        .reverse()
        .find((item) => item.task_id === currentTask(latest)?.task_id && item.text_type !== 'auto' && item.text_type !== 'auto_interpretation')
      logEvent(latest, sketchStage ? 'user_prompt_change' : 'text_change', {
        text_length: latest.runtime.draft_text.length,
        ...(sketchStage ? userPromptPayload(latest, previous?.text ?? '') : {}),
      })
      persist(latest)
    }, 800)
  }

  function onSketchChange(scene: SketchScene, action?: SketchEdit) {
    const latest = structuredClone(getSession(session.participant_id) ?? session)
    if (!latest.runtime.sketch_editing) {
      latest.runtime.sketch_editing = true
      logEvent(latest, 'sketch_edit_start')
    }
    latest.runtime.working_scene = cloneScene(scene)
    if (action) {
      addSketchAction(
        latest,
        action.action_type || action.action,
        action.target_id || action.target,
        action.before_state,
        action.after_state,
      )
    }
    persist(latest)
    setSession(latest)
  }

  const generating = session.runtime.step === 'generating'
  const showSketch = Boolean(task.sketch_enabled)
  const prompt =
    task.stage === 'T0'
      ? t.observeT0
      : task.stage === 'T3'
        ? session.runtime.step === 'review'
          ? t.refineT3
          : t.observeT3
        : session.runtime.step === 'review'
          ? t.refine
          : t.observeAdjust

  return (
    <SessionChrome
      session={session}
      title={`${task.stage} · ${session.runtime.task_index + 1}/${planLength}`}
      extra={generating ? t.generating : session.participant_id}
      onSessionChange={setSession}
      onOpenTask={jumpToTask}
    >
      <div className="workspace-wrap">
        <TaskWorkspace
          image={image}
          stage={task.stage}
          round={session.runtime.round}
          text={session.runtime.draft_text}
          autoPrompt={session.runtime.auto_prompt}
          prompt={prompt}
          scene={session.runtime.working_scene}
          showSketch={showSketch}
          lastGenerationId={lastGen?.generation_id || ''}
          generateError={session.runtime.generate_error}
          canInterpret={canInterpret}
          onInterpretSketch={runInterpretSketch}
          onTextFocus={() =>
            update((next) => {
              logEvent(next, 'text_focus')
            })
          }
          onTextChange={onTextChange}
          onSketchChange={onSketchChange}
          onCopyAuto={() =>
            update((next) => {
              recordCopyEvent(next, 'auto_prompt', next.runtime.auto_prompt)
            })
          }
          onPasteUser={(pasted) =>
            update((next) => {
              recordPasteEvent(next, pasted, pastedFromAuto(next.runtime.auto_prompt, pasted))
            })
          }
          onSelect={(id) =>
            update((next) => {
              next.runtime.selected_node_id = id
              logEvent(next, 'sketch_select', { target_id: id })
            })
          }
        />
        {generating ? (
          <div className="generating-mask" role="status">
            <p className="lead">{t.generating}</p>
            <p className="hint">{t.generatingHint}</p>
          </div>
        ) : null}
      </div>
      <FooterBar style={{ justifyContent: 'space-between' }}>
        <Button onClick={() => confirmRestart(session, t.restartConfirm, t.cancel, t.confirmRestart)}>{t.startOver}</Button>
        <div className="stack-row">
          {generating ? (
            <Button fill onClick={() => abandonInFlightGenerate('cancel')}>
              {t.cancelWait}
            </Button>
          ) : null}
          {!generating && task.stage === 'T0' ? (
            <Button fill disabled={!canSatisfy} onClick={finishTask}>
              {t.submit}
            </Button>
          ) : null}
          {!generating && task.stage !== 'T0' && canGenerate ? (
            <Button fill disabled={session.runtime.draft_text.trim().length === 0} onClick={() => void runGenerate()}>
              {t.generate}
              {session.runtime.round > 0 ? ` (${session.runtime.round}/${MAX_ROUNDS})` : ''}
            </Button>
          ) : null}
          {!generating && task.stage !== 'T0' && canSatisfy ? (
            <Button onClick={finishTask}>{t.satisfied}</Button>
          ) : null}
          {!generating && task.stage === 'T2' && !canSatisfy ? <p className="hint">{t.t2SatisfyHint}</p> : null}
        </div>
      </FooterBar>
    </SessionChrome>
  )
}

function TaskWorkspace({
  image,
  stage,
  round,
  text,
  autoPrompt,
  prompt,
  scene,
  showSketch,
  lastGenerationId,
  generateError,
  canInterpret,
  onInterpretSketch,
  onTextFocus,
  onTextChange,
  onSketchChange,
  onCopyAuto,
  onPasteUser,
  onSelect,
}: {
  image: ImageDef
  stage: TaskRun['stage']
  round: number
  text: string
  autoPrompt: string
  prompt: string
  scene: SketchScene | null
  showSketch: boolean
  lastGenerationId: string
  generateError: string
  canInterpret: boolean
  onInterpretSketch: () => void
  onTextFocus: () => void
  onTextChange: (value: string) => void
  onSketchChange: (scene: SketchScene, action?: SketchEdit) => void
  onCopyAuto: () => void
  onPasteUser: (pasted: string) => void
  onSelect: (id: string | null) => void
}) {
  const columns = stage === 'T0' ? 'workspace-t0' : showSketch ? 'workspace-t2' : 'workspace-t1'
  const splitPrompt = showSketch
  const { t, format } = useI18n()
  return (
    <main className={`workspace ${columns}`}>
      <section>
        <h2>{t.currentImage}</h2>
        {lastGenerationId ? (
          <GeneratedImage trialId={lastGenerationId} />
        ) : (
          <img className="stimulus-small" src={stimulusUrl(image.image_path)} alt="" />
        )}
      </section>
      {showSketch ? (
        <section>
          <h2>{t.sketch}</h2>
          {scene ? (
            <SceneEditor scene={scene} onChange={onSketchChange} onSelect={onSelect} />
          ) : (
            <div className="empty-sketch">{t.sketch}</div>
          )}
          <div className="sketch-toolbar">
            <Button disabled={!canInterpret} onClick={onInterpretSketch}>
              {t.interpretSketch}
            </Button>
            <p className="hint">{t.interpretSketchHint}</p>
          </div>
        </section>
      ) : null}
      {stage !== 'T0' ? (
        <section>
          <h2>{t.generated}</h2>
          {lastGenerationId ? (
            <GeneratedImage trialId={lastGenerationId} />
          ) : (
            <div className="empty-sketch">{t.emptyGenerated}</div>
          )}
          {generateError ? <p className="hint">{generateError}</p> : null}
          {round > 0 ? <p className="hint">{format(t.round, { n: round, max: MAX_ROUNDS })}</p> : null}
        </section>
      ) : null}
      {splitPrompt ? (
        <div className="prompt-split">
          <section>
            <h2>{t.aiInterpretation}</h2>
            <p className="hint">{t.autoPromptHint}</p>
            <div className={autoPrompt ? 'auto-prompt' : 'auto-prompt empty'} onCopy={onCopyAuto}>
              {autoPrompt || t.autoPromptEmpty}
            </div>
          </section>
          <section>
            <h2>{t.userPrompt}</h2>
            <p className="hint">{prompt}</p>
            <textarea
              value={text}
              onFocus={onTextFocus}
              onChange={(e) => onTextChange(e.target.value)}
              onPaste={(e) => onPasteUser(e.clipboardData.getData('text'))}
            />
          </section>
        </div>
      ) : (
        <section className="desc-pane">
          <h2>{t.description}</h2>
          <p className="hint">{prompt}</p>
          <textarea
            value={text}
            onFocus={onTextFocus}
            onChange={(e) => onTextChange(e.target.value)}
            onPaste={(e) => onPasteUser(e.clipboardData.getData('text'))}
          />
        </section>
      )}
    </main>
  )
}

function GeneratedImage({ trialId }: { trialId: string }) {
  const { t } = useI18n()
  const [src, setSrc] = useState<string | null | undefined>(undefined)
  useEffect(() => {
    let cancelled = false
    setSrc(undefined)
    void getGeneratedImage(trialId)
      .then((value) => {
        if (!cancelled) setSrc(value)
      })
      .catch(() => {
        if (!cancelled) setSrc(null)
      })
    return () => {
      cancelled = true
    }
  }, [trialId])
  if (src === undefined) return <div className="empty-sketch">{t.loadingGenerated}</div>
  if (!src) return <div className="empty-sketch">{t.emptyGenerated}</div>
  return <img className="generated" src={src} alt="" />
}

function SelfReport({
  session,
  onChange,
  onRestart,
  onSubmit,
  onSessionChange,
  onOpenTask,
}: {
  session: Session
  onChange: (selfAlignment: number | null, resultAlignment: number | null) => void
  onRestart: () => void
  onSubmit: () => void
  onSessionChange: (session: Session) => void
  onOpenTask: (index: number) => void
}) {
  const { t } = useI18n()
  const task = currentTask(session)
  const ready = Boolean(task?.self_alignment_rating && task?.result_alignment_rating)
  return (
    <SessionChrome
      session={session}
      title={t.selfReportTitle}
      extra={session.participant_id}
      onSessionChange={onSessionChange}
      onOpenTask={onOpenTask}
    >
      <main className="page">
        <Likert
          label={t.selfAlignment}
          hint={t.selfAlignmentHint}
          value={task?.self_alignment_rating ?? null}
          onChange={(n) => onChange(n, task?.result_alignment_rating ?? null)}
        />
        <Likert
          label={t.resultAlignment}
          hint={t.resultAlignmentHint}
          value={task?.result_alignment_rating ?? null}
          onChange={(n) => onChange(task?.self_alignment_rating ?? null, n)}
        />
      </main>
      <FooterBar style={{ justifyContent: 'space-between' }}>
        <Button onClick={onRestart}>{t.startOver}</Button>
        <Button fill disabled={!ready} onClick={onSubmit}>
          {t.continue}
        </Button>
      </FooterBar>
    </SessionChrome>
  )
}

function Questionnaire({
  session,
  onChange,
  onRestart,
  onSubmit,
  onSessionChange,
  onOpenTask,
}: {
  session: Session
  onChange: (value: SubjectiveRatings) => void
  onRestart: () => void
  onSubmit: () => void
  onSessionChange: (session: Session) => void
  onOpenTask: (index: number) => void
}) {
  const { t } = useI18n()
  const value = session.subjective ?? {
    perceived_control: null,
    perceived_usefulness: null,
    cognitive_effort: null,
    confidence: null,
  }
  const ready =
    value.perceived_control &&
    value.perceived_usefulness &&
    value.cognitive_effort &&
    value.confidence
  return (
    <SessionChrome
      session={session}
      title={t.questionnaireTitle}
      extra={session.participant_id}
      onSessionChange={onSessionChange}
      onOpenTask={onOpenTask}
    >
      <main className="page">
        <p className="lead">{t.questionnaireLead}</p>
        <Likert
          label={t.control}
          hint={t.controlHint}
          value={value.perceived_control}
          onChange={(n) => onChange({ ...value, perceived_control: n })}
        />
        <Likert
          label={t.usefulness}
          hint={t.usefulnessHint}
          value={value.perceived_usefulness}
          onChange={(n) => onChange({ ...value, perceived_usefulness: n })}
        />
        <Likert
          label={t.effort}
          hint={t.effortHint}
          value={value.cognitive_effort}
          onChange={(n) => onChange({ ...value, cognitive_effort: n })}
        />
        <Likert
          label={t.confidence}
          hint={t.confidenceHint}
          value={value.confidence}
          onChange={(n) => onChange({ ...value, confidence: n })}
        />
      </main>
      <FooterBar style={{ justifyContent: 'space-between' }}>
        <Button onClick={onRestart}>{t.startOver}</Button>
        <Button fill disabled={!ready} onClick={onSubmit}>
          {t.submit}
        </Button>
      </FooterBar>
    </SessionChrome>
  )
}
