import { nowMs } from '../time'
import type { Point, SketchEdit, SketchScene, SubjectNode } from '../types'
import { cloneScene } from './templates'

function nextId(prefix: string, existing: string[]): string {
  let n = 1
  while (existing.includes(`${prefix}_${String(n).padStart(2, '0')}`)) n += 1
  return `${prefix}_${String(n).padStart(2, '0')}`
}

function findSubject(scene: SketchScene, id: string): SubjectNode | undefined {
  return scene.subjects.find((item) => item.id === id)
}

export function captureElement(scene: SketchScene, id: string): unknown {
  if (id === 'camera') return { ...scene.camera }
  const subject = findSubject(scene, id)
  if (subject) return { ...subject }
  const object = scene.objects.find((item) => item.id === id)
  if (object) return { ...object }
  const gaze = scene.gazes.find((item) => item.id === id)
  if (gaze) return { ...gaze }
  const movement = scene.movements.find((item) => item.id === id)
  if (movement) return { ...movement }
  return null
}

export function applySketchAction(scene: SketchScene, action: SketchEdit): SketchScene {
  const next = cloneScene(scene)
  const kind = action.action_type || action.action
  const target = action.target_id || action.target

  if (kind === 'move' || kind === 'move_subject') {
    const subject = findSubject(next, target)
    const point = action.to as Point | undefined
    if (subject && point) {
      subject.x = point.x
      subject.y = point.y
    }
    return next
  }

  if (kind === 'move_object') {
    const object = next.objects.find((item) => item.id === target)
    const point = action.to as Point | undefined
    if (object && point) {
      object.x = point.x
      object.y = point.y
    }
    return next
  }

  if (kind === 'rotate' || kind === 'rotate_subject') {
    const subject = findSubject(next, target)
    if (subject && typeof action.to === 'number') subject.rotation = action.to
    return next
  }

  if (kind === 'camera_move') {
    const point = action.to as Point | undefined
    if (point) {
      next.camera.x = point.x
      next.camera.y = point.y
    }
    return next
  }

  if (kind === 'camera_rotate') {
    if (typeof action.to === 'number') next.camera.rotation = action.to
    return next
  }

  if (kind === 'add' || kind === 'add_subject') {
    const point = (action.to as Point | undefined) ?? { x: 400, y: 260 }
    const id = nextId('person', next.subjects.map((item) => item.id))
    const label = String.fromCharCode(65 + next.subjects.length)
    next.subjects.push({
      id,
      label,
      x: point.x,
      y: point.y,
      rotation: 0,
      scale: 1,
    })
    return next
  }

  if (kind === 'add_object') {
    const point = (action.to as Point | undefined) ?? { x: 360, y: 140 }
    const id = nextId('object', next.objects.map((item) => item.id))
    next.objects.push({
      id,
      kind: 'object',
      label: 'object',
      x: point.x - 30,
      y: point.y - 20,
      w: 80,
      h: 50,
    })
    return next
  }

  if (kind === 'delete' || kind === 'delete_subject') {
    next.subjects = next.subjects.filter((item) => item.id !== target)
    next.gazes = next.gazes.filter((item) => item.from !== target && item.toId !== target)
    next.movements = next.movements.filter((item) => item.from !== target)
    return next
  }

  if (kind === 'delete_object') {
    next.objects = next.objects.filter((item) => item.id !== target)
    return next
  }

  if (kind === 'gaze_add') {
    const to = action.to as { toId?: string | null; to?: Point | null }
    const id = nextId('gaze', next.gazes.map((item) => item.id))
    next.gazes.push({
      id,
      from: target,
      toId: to?.toId ?? null,
      to: to?.to ?? null,
    })
    return next
  }

  if (kind === 'gaze_delete') {
    next.gazes = next.gazes.filter((item) => item.id !== target)
    return next
  }

  if (kind === 'movement_add') {
    const point = action.to as Point
    const id = nextId('movement', next.movements.map((item) => item.id))
    next.movements.push({ id, from: target, to: point })
    return next
  }

  if (kind === 'movement_delete') {
    next.movements = next.movements.filter((item) => item.id !== target)
    return next
  }

  if (kind === 'movement_update' || kind === 'change_direction') {
    const movement = next.movements.find((item) => item.id === target)
    const point = action.to as Point | undefined
    if (movement && point) movement.to = point
    return next
  }

  if (kind === 'resize') {
    const object = next.objects.find((item) => item.id === target)
    const size = action.to as { w?: number; h?: number; scale?: number } | undefined
    if (object && size) {
      if (size.w) object.w = size.w
      if (size.h) object.h = size.h
    }
    const subject = findSubject(next, target)
    if (subject && size?.scale) subject.scale = size.scale
    return next
  }

  if (kind === 'change_distance' || kind === 'camera_distance') {
    if (typeof action.to === 'number') next.camera.distance = action.to
    return next
  }

  if (kind === 'change_layer' || kind === 'change_depth') {
    const y = typeof action.to === 'number' ? action.to : (action.to as { y?: number } | undefined)?.y
    if (y == null) return next
    const subject = findSubject(next, target)
    if (subject) subject.y = y
    const object = next.objects.find((item) => item.id === target)
    if (object) object.y = y
    return next
  }

  return next
}

export function decorateAction(
  scene: SketchScene,
  partial: { action: string; target: string; from?: unknown; to?: unknown },
): { scene: SketchScene; action: SketchEdit } {
  const before = captureElement(scene, partial.target)
  const draft: SketchEdit = {
    action: partial.action,
    action_type: partial.action,
    target: partial.target,
    target_id: partial.target,
    from: partial.from,
    to: partial.to,
    timestamp: nowMs(),
    before_state: before,
    after_state: null,
  }
  const next = applySketchAction(scene, draft)
  let afterId = partial.target
  if (partial.action === 'add' || partial.action === 'add_subject') {
    afterId = next.subjects.at(-1)?.id ?? partial.target
  } else if (partial.action === 'add_object') {
    afterId = next.objects.at(-1)?.id ?? partial.target
  } else if (partial.action === 'gaze_add') {
    afterId = next.gazes.at(-1)?.id ?? partial.target
  } else if (partial.action === 'movement_add') {
    afterId = next.movements.at(-1)?.id ?? partial.target
  }
  return {
    scene: next,
    action: {
      ...draft,
      target_id: afterId,
      after_state: captureElement(next, afterId),
    },
  }
}

export function logOnlyAction(
  scene: SketchScene,
  partial: { action: string; target: string; from?: unknown; to?: unknown },
): SketchEdit {
  return {
    action: partial.action,
    action_type: partial.action,
    target: partial.target,
    target_id: partial.target,
    from: partial.from,
    to: partial.to,
    timestamp: nowMs(),
    before_state: partial.from ?? captureElement(scene, partial.target),
    after_state: partial.to ?? captureElement(scene, partial.target),
  }
}

export function nodeCenter(scene: SketchScene, id: string): Point | null {
  if (id === 'camera') return { x: scene.camera.x, y: scene.camera.y }
  const subject = findSubject(scene, id)
  if (subject) return { x: subject.x, y: subject.y }
  const object = scene.objects.find((item) => item.id === id)
  if (object) return { x: object.x + object.w / 2, y: object.y + object.h / 2 }
  const movement = scene.movements.find((item) => item.id === id)
  if (movement) return { ...movement.to }
  return null
}
