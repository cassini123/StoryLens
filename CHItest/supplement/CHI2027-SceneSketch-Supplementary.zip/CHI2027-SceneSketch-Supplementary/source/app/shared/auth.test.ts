import { afterEach, describe, expect, it } from 'vitest'
import { isResearcherAuthed, loginResearcher, logoutResearcher, researcherName } from './auth'

afterEach(() => {
  logoutResearcher()
})

describe('researcher login', () => {
  it('accepts the two study accounts', () => {
    expect(loginResearcher('researcher-a', '<redacted>')).toBe(true)
    expect(researcherName()).toBe('researcher-a')
    expect(isResearcherAuthed()).toBe(true)
    logoutResearcher()
    expect(loginResearcher('researcher-b', '<redacted>')).toBe(true)
    expect(researcherName()).toBe('researcher-b')
  })

  it('rejects a wrong password or unknown account', () => {
    expect(loginResearcher('researcher-a', 'wrong')).toBe(false)
    expect(loginResearcher('mickey', '<redacted>')).toBe(false)
    expect(isResearcherAuthed()).toBe(false)
  })
})
