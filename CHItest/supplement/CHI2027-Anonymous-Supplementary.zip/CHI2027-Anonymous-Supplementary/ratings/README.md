# Scoring tables

## Filled (this study)

- `评分表-被试自评.csv` / `self_alignment.csv` — per-task participant ratings, 1–7.
  `self_alignment` = how well the final wording matched the intended change.
  `result_alignment` = how well the generated image matched the intended picture.
- `评分表.csv` / `scoring-sheet.csv` — one row per participant × task, with the
  filled 1–7 columns and empty expert 0–3 columns (`P_norm` empty).
- `demographics.csv` — cinematography / visual / generative-AI experience.
- `session-index.csv` — completeness flags for the n=20 freeze.

## Expert rubric (not yet filled)

Experts score the **wording**, not likeness to the still. Scale 0–3 on:

- intent_precision
- intent_interpretability
- spatial_specificity
- executability

`P_i` = sum of active criteria. `P_norm` = P_i / (3 × number of active criteria).
Plain language can receive 3 if it is executable. Jargon is never enough for a 3.

`expert_ratings.csv` is header-only: no expert submitted scores in this deployment.
Fill `评分表.csv` expert columns (or export from the expert page) and replace that file.

End-of-session Likert (control / usefulness / effort / confidence) was shown in
the client but was not written into the official export tables.
