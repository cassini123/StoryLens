# Image library

Still frames shown to participants as the current visual state.
Researcher target-modification notes are in `metadata/target_modifications.json`
and were **never shown** to participants.

Packed files: 30 PNG, 20 SVG.

| group | folder | ids |
| --- | --- | --- |
| environment | `environment/` | E01–E05 |
| character / space | `character_space/` | C01–C04 |
| camera | `camera/` | A01–A15 (A01–A05 used in the study; A06–A15 extra pool) |
| composition | `composition/` | D01–D06 |

Study stills used in the 7-task sessions are E01–E05, C01–C04, A01–A05, D01–D06.

| ID | scene |
| --- | --- |
| E01 | empty theatre |
| E02 | ferry deck |
| E03 | bookstore entrance |
| E04 | park bench |
| E05 | foreground / background |
| C01 | train-station window |
| C02 | cafe facing pair |
| C03 | courtyard facing pair |
| C04 | street corner, three people |
| A01 | stair low angle |
| A02 | museum wall |
| A03 | corridor from above |
| A04 | subway approaching |
| A05 | bench, distracted |
| D01 | half-hidden behind a column |
| D02 | figure behind a door |
| D03 | corridor direction |
| D04 | gallery crossing |
| D05 | dining table, three people |
| D06 | inside / outside glass |
