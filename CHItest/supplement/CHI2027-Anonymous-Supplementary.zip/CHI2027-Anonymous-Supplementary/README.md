# Supplementary materials

Anonymous supplementary package for a CHI 2027 paper on a temporary visual
scaffold for precise natural-language image editing.

This archive is **self-contained**. It does not include product source code,
repository URLs, live study URLs, author or institution names, or credentials.

## Contents

```
README.md
experiment-design/
  experiment-protocol.md
  experiment.json
  questionnaires.md
image-library/
  CATALOG.md
  environment/ C01–style stills as PNG + SVG
  character_space/
  camera/
  composition/
  metadata/                 stimuli and target-modification JSON
participants/
  INDEX.csv
  P001/ … P026/             official session tables (no embedded images)
ratings/
  评分表.csv                  participant 1–7 + empty expert 0–3 columns
  评分表-被试自评.csv           filled self-alignment / result-alignment
  self_alignment.csv
  scoring-sheet.csv
  demographics.csv
  session-index.csv
  expert_ratings.csv           expert rubric (empty in this deployment)
```

## Participants

26 collected sessions (16 scaffold, 10 control), including
incomplete / failed-validation sessions. Inclusion rules are in
`experiment-design/experiment-protocol.md`.

Official tables in each `participants/PXXX/` folder:

- `participants.csv`, `tasks.csv`, `event_log.csv` / `events.csv`
- `text_versions.csv`, `generations.csv`
- `sketch_interactions.csv`, `sketch_snapshots.json`, `auto_prompts.csv`
- `self_alignment.csv`, `expert_ratings.csv`
- `full_session_timeline.json`, `validation.json`, `session_recovery.json`

Raw session JSON with embedded generated images is omitted (would exceed
the 300 MB limit). The **stimulus image library** is included in full.

## Ratings

Per-task `self_alignment` and `result_alignment` (1–7) are in
`ratings/self_alignment.csv`. Expert `P_norm` was not collected
(`ratings/expert_ratings.csv` is header-only).

## Anonymization

- Session IDs are labels `P001`…`P026`.
- Typed nicknames were rewritten to those labels.
- Author, researcher, expert, product, and repository identifiers were removed.
- Do not host this archive on a public repository that also contains
  identifiable projects.

## Ethics

For confidential paper review only. Do not redistribute participant logs.
