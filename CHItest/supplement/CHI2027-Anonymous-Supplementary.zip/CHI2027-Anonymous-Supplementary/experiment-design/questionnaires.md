# Questionnaires and in-task items

Items below are the participant-facing study copy.
Chinese is the language shown to participants. English is included for reviewers.
No free-text interview was collected.

## 0. Session setup (before the first task)

| id | Chinese | English | response |
| --- | --- | --- | --- |
| participant_id | 被试编号 | Participant ID | text (analysis uses zip labels P001–P026) |
| cineExp | 影像 / 摄影经验 | Cinematography / photography experience | 没有 / 有一些 / 经常接触 |
| cineYears | 影像经验年数（没有就填 0） | Years of cinematography experience (0 if none) | integer |
| visualExp | 视觉 / 设计经验 | Visual / design experience | 没有 / 有一些 / 经常接触 |
| aiFam | 对生成式 AI 的熟悉程度 | Familiarity with generative AI | 没有 / 有一些 / 经常接触 |

English option labels: None / Some / Frequent.

## A. Per-task self-report (after each T1/T2/T3, before Next)

Scale: 1–7.

| id | Chinese | English |
| --- | --- | --- |
| self_alignment | 你最终想让 AI 完成的修改，与你原本想表达的内容有多一致？ | How well does the change you finally asked the AI to make match what you originally wanted to express? |
| result_alignment | 当前生成结果与你想表达的画面有多一致？ | How well does the current generated result match the picture you wanted to express? |

Anchors (zh): 1 = 完全不一致，7 = 完全一致。`self_alignment` 不是在给生成图打分。
Anchors (en): 1 = not at all, 7 = completely. `self_alignment` is not a score for the generated image.

`self_alignment` is the interaction-level precision proxy used when expert `P_norm` is unavailable.
`result_alignment` is recorded but is not the primary precision claim (model image quality is out of scope).

## B. End-of-session Likert (four items, 1–7)

Lead (zh): 下面几题是次要的，请按整场实验的整体感受作答。
Lead (en): These questions are secondary. Answer based on the session as a whole.

| id | Chinese label / hint | English label / hint |
| --- | --- | --- |
| perceived_control | 掌控感 — 你觉得自己在多大程度上把想要的画面表达清楚了？ | Perceived control — How much control did you feel over expressing your intended picture? |
| perceived_usefulness | 有帮助 — 这个过程对你理清自己想要的画面有多大帮助？ | Perceived usefulness — How useful was the process for clarifying your intention? |
| effort | 费力程度 — 整场实验需要你花多少心力？ | Cognitive effort — How much mental effort did the session require? |
| confidence | 把握 — 如果换一个人来布置你想要的画面，你觉得他能多大程度上做对？ | Confidence — How confident are you that someone else could stage your intended pictures? |

## C. T0 observation prompt (no generation)

Chinese: 请观察这张图，用你自己的语言描述你从这个画面中读到的视觉信息。你可以描述人物、空间、位置关系、构图、镜头、动作或氛围。没有标准答案，也不需要使用专业术语。

English: Look at this picture. In your own words, describe the visual information you read from the frame. You can mention people, space, positions, composition, the camera, action, or atmosphere. There is no single correct answer, and you do not need professional terms.

## D. T1 / T2 / T3 generation prompt

Chinese: 这是当前的视觉状态，描述你认为下一个镜头里会发生的内容。生成结果出现后，请观察它与自己想表达的效果有什么差异，并再次修改你的描述，让下一次生成更接近你的想法。没有设定标准答案，自由发挥！（我们提供<=3的修改轮次）

English: This is the current visual state. Describe what you think happens in the next shot. After the result appears, look at how it differs from what you wanted to express, and revise your description again so the next generation is closer. There is no set correct answer — feel free to improvise! (You have up to 3 revision rounds.)

Internal codes T0–T3 are never shown to participants.

### T2-only (scaffold group)

- Button: 生成文字解释 / Interpret Sketch
- Hint: 拖草图不会自动出字。改完后请点这一按钮，才会根据当前草图生成文字解释。
- Constraint: 请先改草图，点击「生成文字解释」，修改描述后再生成一次，才能进入下一题。
- The sketch is not sent to the image API (`sketch_sent=false`, `api_input=image+text`).

## E. Where responses live

- Setup / demographics: `ratings/demographics.csv` and `participants/PXXX/participants.csv`
- Per-task Likert: `ratings/self_alignment.csv`
- Expert rubric: `ratings/expert_ratings.csv` (empty in this deployment)
- Prompts: `participants/PXXX/text_versions.csv` (identifiers rewritten to zip labels)

The end-of-session Likert (perceived control / usefulness / effort / confidence) was shown in the client but was not written into the official export tables.
